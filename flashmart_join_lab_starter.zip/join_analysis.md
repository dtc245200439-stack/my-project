# JOIN Analysis

## Giai thich COUNT(o.order_id) va COUNT(*)

Hoan thanh phan nay bang loi giai thich cua chinh ban (duoi 150 tu).

Goi y de tu dien:
- Khi LEFT JOIN khong tim thay don hang, cac cot cua Orders se co gia tri ______.
- COUNT(ten_cot) dem cac gia tri ______ va bo qua gia tri ______.
- COUNT(*) dem so ______ trong ket qua JOIN, ke ca dong duoc tao ra de giu khach hang chua co don hang.
- Vi vay, voi bai toan nay, COUNT(o.order_id) cho Charlie ket qua ______, trong khi COUNT(*) co the cho ket qua ______.
