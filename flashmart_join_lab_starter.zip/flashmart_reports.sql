-- FLASHMART: JOIN ANALYSIS AND REPORTS
-- Ho ten: Lo Van Bac
-- Lop: CNTT K23E
-- MSV: DTC245200439
--
-- Huong dan:
-- 1) Chay phan tao CSDL va du lieu mau.
-- 2) Tu hoan thanh hai truy van trong cac khung TODO theo yeu cau de bai.
-- 3) Chay lai va doi chieu ket qua mong doi o cuoi file.

CREATE DATABASE IF NOT EXISTS flashmart_db;
USE flashmart_db;

DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(50)
);

CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50)
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT
);

INSERT INTO Customers VALUES
(1, 'Alice'),
(2, 'Bob'),
(3, 'Charlie');

INSERT INTO Products VALUES
(101, 'Laptop'),
(102, 'Mouse'),
(103, 'Keyboard');

INSERT INTO Orders VALUES
(1001, 1, 101),
(1002, 1, 102),
(1003, 2, 101);

-- TODO 1 - BAO CAO MARKETING
-- Muc tieu: hien thi tat ca khach hang va so don hang cua moi nguoi.
-- Goi y:
-- * Bang goc (driving table) phai la Customers.
-- * Chon loai JOIN giu lai ca khach hang khong co don hang.
-- * COUNT cot khoa chinh cua Orders, khong dung COUNT(*).
-- * GROUP BY cac cot khach hang duoc hien thi.
-- Hay viet truy van cua anh ben duoi:
-- [VIET TRUY VAN 1 O DAY]


-- TODO 2 - BAO CAO KHO VAN (ANTI-JOIN)
-- Muc tieu: tim san pham chua tung xuat hien trong don hang.
-- Goi y:
-- * Bang goc phai la Products.
-- * LEFT JOIN sang Orders theo product_id.
-- * Loc dong ma khoa don hang ben Orders la NULL.
-- Hay viet truy van cua anh ben duoi:
-- [VIET TRUY VAN 2 O DAY]


-- KET QUA MONG DOI DE DOI CHIEU
-- Bao cao Marketing phai co 3 dong:
-- Alice   = 2 don
-- Bob     = 1 don
-- Charlie = 0 don
--
-- Bao cao Kho van phai co dung 1 dong:
-- 103, Keyboard
