# FlashMart JOIN Lab - Huong dan hoan thien

File trong goi:
- `flashmart_reports.sql`: tao CSDL va du lieu mau; co 2 vi tri TODO de ban tu viet truy van.
- `join_analysis.md`: khung giai trinh COUNT, gioi han duoi 150 tu.
- `ai_prompt_log.md`: mau nhat ky hoc tap, can chinh sua theo qua trinh thuc te.

## Cach lam
1. Mo MySQL Workbench (hoac cong cu MySQL ban dang dung).
2. Mo va chay `flashmart_reports.sql` de tao CSDL va du lieu mau.
3. Hoan thanh hai truy van tai vi tri TODO, sau do chay tung truy van.
4. Doi chieu ket qua: bao cao Marketing co 3 dong (Alice 2, Bob 1, Charlie 0); bao cao Kho van co 1 dong (103, Keyboard).
5. Hoan thanh `join_analysis.md` bang loi cua ban (duoi 150 tu).
6. Sua `ai_prompt_log.md` de phan anh dung nhung gi ban da hoi va hoc duoc.
7. Chup anh Result Grid cho ca hai bao cao.
8. Nen 3 file duoc yeu cau cung anh minh chung neu giang vien cho phep, roi nop file ZIP.

Luu y: Khong nop nguyen cac khung TODO. Hay tu viet truy van, chay va xac minh ket qua truoc khi nop.
