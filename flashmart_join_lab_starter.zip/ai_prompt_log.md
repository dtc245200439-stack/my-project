# AI Prompt Log - FlashMart JOIN Lab

Ghi lai cac cau hoi anh thuc su da hoi AI va tom tat bang loi cua minh. Khong ghi mot cau hoi/tra loi ma anh chua doc va chua hieu.

## Lan 1 - INNER JOIN va LEFT JOIN
**Prompt da dung:**
Trong MySQL, INNER JOIN va LEFT JOIN khac nhau the nao neu bang ben trai co ban ghi khong tim thay ban ghi tuong ung ben phai?

**Tom tat cua toi:**
[Tu viet 2-4 cau bang loi cua minh.]

## Lan 2 - COUNT voi LEFT JOIN
**Prompt da dung:**
Khi LEFT JOIN va dem so don hang, COUNT(*) khac COUNT(order_id) nhu the nao neu khach hang chua co don hang?

**Tom tat cua toi:**
[Tu viet 2-4 cau bang loi cua minh.]

## Lan 3 - Anti-Join va hieu nang
**Prompt da dung:**
Giai thich LEFT JOIN ... IS NULL va NOT EXISTS de tim ban ghi khong co ban ghi lien quan; khi nao can chu y den NULL va index?

**Tom tat cua toi:**
[Tu viet 2-4 cau bang loi cua minh.]

## Lan 4 - Nested-Loop Join
**Prompt da dung:**
Nested-Loop Join la gi? MySQL optimizer co the dung index de lam giam chi phi JOIN nhu the nao?

**Tom tat cua toi:**
[Tu viet 2-4 cau bang loi cua minh.]
